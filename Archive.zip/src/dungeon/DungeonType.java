package dungeon;

/**
 * Enum indicating the type of dungeon in the game.
 */
public enum DungeonType {
  WRAPPING, NON_WRAPPING
}
