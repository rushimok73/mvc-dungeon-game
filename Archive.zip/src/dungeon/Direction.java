package dungeon;

/**
 * Enum to indicate the possible directions a player can go in.
 */
public enum Direction {
  NORTH, SOUTH, WEST, EAST
}
