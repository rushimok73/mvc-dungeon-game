package dungeon;

/**
 * Enum representing treasures inside the dungeon.
 */
public enum Treasure {
  RUBIES, DIAMONDS, SAPPHIRES, ARROWS
}
